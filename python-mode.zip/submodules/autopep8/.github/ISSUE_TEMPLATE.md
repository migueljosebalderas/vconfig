
---

## Python Code
```python

YOUR CODE
```

## Command Line and Configuration
`.pep8`, `setup.cfg`, ...

```ini
[pep8]

```

Command Line
```shell
$ autopep8 
```

## Your Environment
* Python version:
* autopep8 version:
* Platform: windows, linux, macOSX, and other OS...

