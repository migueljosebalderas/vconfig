#: Okay
# 情
#: W291
print 
#: W293
class Foo(object):
    
    bang = 12
#: W291
'''multiline
string with trailing whitespace'''   
#: W292
# This line doesn't have a linefeed