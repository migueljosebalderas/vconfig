Please read the [contribute doc](https://github.com/PyCQA/pylint/blob/master/doc/development_guide/contribute.rst).
