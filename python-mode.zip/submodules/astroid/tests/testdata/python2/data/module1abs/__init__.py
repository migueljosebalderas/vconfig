from __future__ import absolute_import, print_function
from . import core
from .core import *
print(sys.version)
