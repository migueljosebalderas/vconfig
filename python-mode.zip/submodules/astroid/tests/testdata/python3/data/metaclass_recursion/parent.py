# https://github.com/PyCQA/astroid/issues/749
class OriginalClass:
    pass
