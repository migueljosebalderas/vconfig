### Steps to reproduce
1. 
2. 
3. 

### Current behavior


### Expected behavior


### ``python -c "from astroid import __pkginfo__; print(__pkginfo__.version)"`` output

