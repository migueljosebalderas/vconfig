---
name: Support question
about: Questions about pylint that are not covered in the documentation (http://pylint.pycqa.org/en/latest/)

---

## Question
