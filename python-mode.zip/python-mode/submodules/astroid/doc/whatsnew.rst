######################
 What's New in astroid
######################


The "Changelog" contains *all* nontrivial changes to astroid for the current version.

.. toctree::
   :maxdepth: 2

   changelog