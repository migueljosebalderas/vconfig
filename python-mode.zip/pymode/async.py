""" Python-mode async support. """

from queue import Queue # noqa


RESULTS = Queue()
